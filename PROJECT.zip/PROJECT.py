import random

Clubs = ["Arsenal (ENG)","Astana (KAZ)","Atlético (ESP)","BATE (BLR)","CSKA Moskva (RUS)","Dinamo Zagreb (CRO)","Dynamo Kyiv (UKR)","Galatasaray (TUR)","Gent (BEL)","Leverkusen (GER)","Lyon (FRA)","M. Tel-Aviv (ISR)","Malmö (SWE)","Man. City (ENG)","Man. United (ENG)","Mönchengladbachn (GER)","Olympiacos (GRE)","Porto (POR)","Real Madrid (ESP)","Roma (ITA)","Sevilla (ESP)","Shakhtar Donetsk (UKR)","Valencia (ESP)","Wolfsburg (GER)"]
Domestic = ["Barcelona (ESP)","Bayern (GER)","Benfica (POR)","Chelsea (ENG)","Juventus (ITA)","Paris (FRA)","PSV (NED)","Zenit (RUS)"]
GROUP_A = []
GROUP_B = []
GROUP_C = []
GROUP_D = []
GROUP_E = []
GROUP_F = []
GROUP_G = []
GROUP_H = []

random.shuffle(Clubs)
random.shuffle(Domestic)

for i in Clubs:
            
    if len(GROUP_A) != 3:
        GROUP_A.append(i)
    elif len(GROUP_B) != 3:
        GROUP_B.append(i)
    elif len(GROUP_C) != 3:
        GROUP_C.append(i)
    elif len(GROUP_D) != 3:
        GROUP_D.append(i)
    elif len(GROUP_E) != 3:
        GROUP_E.append(i)
    elif len(GROUP_F) != 3:
        GROUP_F.append(i)
    elif len(GROUP_G) != 3:
        GROUP_G.append(i)
    elif len(GROUP_H) != 3:
        GROUP_H.append(i)
    else:
        continue

for i in Domestic:
    if len(GROUP_A) != 4:
        GROUP_A.append(i)
    elif len(GROUP_B) != 4:
        GROUP_B.append(i)
    elif len(GROUP_C) != 4:
        GROUP_C.append(i)
    elif len(GROUP_D) != 4:
        GROUP_D.append(i)
    elif len(GROUP_E) != 4:
        GROUP_E.append(i)
    elif len(GROUP_F) != 4:
        GROUP_F.append(i)
    elif len(GROUP_G) != 4:
        GROUP_G.append(i)
    elif len(GROUP_H) != 4:
        GROUP_H.append(i)
    else:
        continue
    
print("GROUP A :",GROUP_A)
print("GROUP B :",GROUP_B)
print("GROUP C :",GROUP_C)
print("GROUP D :",GROUP_D)
print("GROUP E :",GROUP_E)
print("GROUP F :",GROUP_F)
print("GROUP G :",GROUP_G)
print("GROUP H :",GROUP_H)
